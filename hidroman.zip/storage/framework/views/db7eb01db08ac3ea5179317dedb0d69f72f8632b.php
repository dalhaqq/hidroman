

<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- column -->
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Gully</h2>
                    <div class="table-responsive">
                        <table class="table user-table no-wrap text-center">
                            <thead>
                                <tr>
                                    <!-- id gully diganti jadi nomor gully supaya petani ga kebingungan, apa itu id?. Tapi db nya ga usah diganti,ttep id aja -->
                                    <th class="border-top-0">Gully</th>
                                    <th class="border-top-0">Waktu Penyiraman</th>
                                    <th class="border-top-0">Status</th>
                                    <!-- atribut Status itu diisi pake logic aja, ga perlu ada di db. If this.id gully ga ada di kloter tanaman, maka status kosong (bisa diisi tanaman). Else statusnya isi -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $gully; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($g->nama); ?></td>
                                    <td>
                                        <?php echo e($g->countdown); ?> hari
                                    </td>
                                    <td class=" px-0">
                                        <!-- If status isi, maka bg-success text-light. Else bg-light text-success -->
                                        <?php if($g->kloter): ?>
                                        <div class="btn shadow-sm bg-success text-light px-5">Isi</div>
                                        <?php else: ?>
                                        <div class="btn shadow-sm bg-light text-success px-5">Kosong</div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">Tidak ada data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalhaqq/Projects/Laravel/hidroman/resources/views/pages/gully.blade.php ENDPATH**/ ?>