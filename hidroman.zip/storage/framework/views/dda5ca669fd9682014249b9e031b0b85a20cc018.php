

<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- column -->
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Riwayat Nutrisi</h2>
                    <div class="table-responsive">
                        <table class="table user-table no-wrap text-center">
                            <thead>
                                <tr>
                                    <!-- Menurutku, id ga perlu dicantumin, ga akan kepake sama petaninya. Biasanya yang diliat itu tanggalnya, bukan idnya. Tapi kalau mau ditambahin, bolehh aja -->
                                    <th class="border-top-0">Tanggal Pemberian Nutrisi</th>
                                    <th class="border-top-0">Gully</th>
                                    <th class="border-top-0">Jenis Nutrisi</th>
                                    <th class="border-top-0">Jumlah Nutrisi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $riwayatNutrisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($rn->tanggal); ?></td>
                                    <td><?php echo e($rn->gully->nama); ?></td>
                                    <td><?php echo e($rn->nutrisi->barang); ?></td>
                                    <td><?php echo e($rn->jml_nutrisi); ?>ml</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalhaqq/Projects/Laravel/hidroman/resources/views/pages/nutrisi.blade.php ENDPATH**/ ?>