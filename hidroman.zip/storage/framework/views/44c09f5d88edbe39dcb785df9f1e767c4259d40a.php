

<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- column -->
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Persediaan Barang</h2>
                    <div class="table-responsive">
                        <table class="table user-table no-wrap text-center">
                            <thead>
                                <tr>
                                    <!-- Menurutku, ga perlu ada id. Karna petani ga butuh id kayanya -->
                                    <!-- <th class="border-top-0">Id Barang</th> -->
                                    <th class="border-top-0">Jenis Barang</th>
                                    <th class="border-top-0">Nama Barang</th>
                                    <th class="border-top-0">Stok</th>
                                    <!-- atribut Status itu diisi pake logic aja, ga perlu ada di db. If this.id gully ga ada di kloter tanaman, maka status kosong (bisa diisi tanaman). Else statusnya isi -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e(ucwords($i->jenis)); ?></td>
                                    <td><?php echo e(ucwords($i->jenis)); ?> <?php echo e($i->barang); ?></td>
                                    <td class="px-0">
                                        <!-- If stok == 0, maka bg-danger text-light. Else bg-light text-success -->
                                        <?php if($i->stok == 0): ?>
                                        <div class="btn shadow-sm bg-danger text-light px-5" style='width:60%;'>0 buah</div>
                                        <?php else: ?>
                                        <div class="btn shadow-sm bg-light text-success px-5" style='width:60%;'><?php echo e($i->stok); ?> buah</div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    Tidak ada data
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalhaqq/Projects/Laravel/hidroman/resources/views/pages/inventory.blade.php ENDPATH**/ ?>