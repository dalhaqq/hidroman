

<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <!-- Row -->
    <div class="row">
        <!-- Column Riwayat Pembelian -->
        <div class=" col-lg-4 col-xlg-9 col-md-7">
            <div class="card shadow">
                <div class="card-title text-center mt-3">
                    <h3>Tambah Riwayat Pembelian</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal form-material mx-2" method="POST" action="<?php echo e(url('pembelian')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="date" class="form-control" id="tanggal" name="tanggal">
                            <label for="tanggal">Tanggal Pembelian</label>
                        </div>
                        <div class="form-group">
                            <label for="inventory_id" class="col-sm-12">Nama Barang</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="inventory_id" name="inventory_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $inventory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($i->id); ?>"><?php echo e(ucfirst($i->jenis)); ?> <?php echo e($i->barang); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" class="form-control" id="jumlah" name="jumlah">
                            <label for="jumlah">Jumlah Barang</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12 d-flex">
                                <button class="btn btn-success mx-auto mx-md-0 text-white">Masukan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Column Riwayat Pembelian -->
        <!-- Column Riwayat Nutrisi -->
        <div class=" col-lg-4 col-xlg-9 col-md-7">
            <div class="card shadow">
                <div class="card-title text-center mt-3">
                    <h3>Tambah Riwayat Nutrisi</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal form-material mx-2" method="POST" action="<?php echo e(url('/nutrisi')); ?>">
                    <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="date" class="form-control" id="tanggal" name="tanggal" placeholder=".">
                            <label for="tanggal">Tanggal Pemberian Nutrisi</label>
                        </div>
                        <div class="form-group">
                            <label for="gully_id" class="col-sm-12">Gully</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="gully_id" name="gully_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $filledGully; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($fg->id); ?>"><?php echo e($fg->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="nutrisi_id" class="col-sm-12">Jenis Nutrisi</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="nutrisi_id" name="nutrisi_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $nutrisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($n->id); ?>"><?php echo e($n->barang); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" class="form-control" id="jml_nutrisi" name="jml_nutrisi">
                            <label for="jml_nutrisi">Jumlah Nutrisi</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12 d-flex">
                                <button class="btn btn-success mx-auto mx-md-0 text-white">Masukan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Column Riwayat Nutrisi -->
        <!-- Column Riwayat Panen -->
        <div class=" col-lg-4 col-xlg-9 col-md-7">
            <div class="card shadow">
                <div class="card-title text-center mt-3">
                    <h3>Tambah Riwayat Panen</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal form-material mx-2" method="POST" action="<?php echo e(url('/panen')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="date" class="form-control" id="tanggal" name="tanggal">
                            <label for="tanggal">Tanggal Panen</label>
                        </div>
                        <div class="form-group">
                            <label for="kloter_id" class="col-sm-12">Nomor Kloter</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="kloter_id" name="kloter_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $kloterAktif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($ka->id); ?>"><?php echo e($ka->id); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-sm-12">Cabut akar?</label>
                            <div class="form-check">
                                <input class="form-check-input" value="1" type="radio" name="cabut" id="cabut-ya">
                                <label class="form-check-label" for="cabut-ya">
                                    Ya
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" value="0" type="radio" name="cabut" id="cabut-tidak" checked>
                                <label class="form-check-label" for="cabut-tidak">
                                    Tidak
                                </label>
                            </div>
                        </div>
                        <div class="form-floating mb-3">
                            <input type="number" class="form-control" id="jumlah" name="jumlah">
                            <label for="jumlah">Berat Hasil Panen</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12 d-flex">
                                <button class="btn btn-success mx-auto mx-md-0 text-white">Masukan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Column Riwayat Panen -->
        <!-- Column Gully -->
        <div class=" col-lg-4 col-xlg-9 col-md-7">
            <div class="card shadow">
                <div class="card-title text-center mt-3">
                    <h3>Tambah Gully Baru</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal form-material mx-2" method="POST" action="<?php echo e(url('/gully')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="nama" name="nama">
                            <label for="nama">Nama Gully</label>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12 d-flex">
                                <button class="btn btn-success mx-auto mx-md-0 text-white">Masukan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Column Gully -->
        <!-- Kloter -->
        <div class=" col-lg-4 col-xlg-9 col-md-7">
            <div class="card shadow">
                <div class="card-title text-center mt-3">
                    <h3>Tambah Kloter Baru</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal form-material mx-2" method="POST" action="<?php echo e(url('/kloter')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-floating mb-3">
                            <input type="date" class="form-control" id="tgl_tanam" name="tgl_tanam">
                            <label for="tgl_tanam">Tanggal Tanam</label>
                        </div>
                        <div class="form-group">
                            <label for="gully_id" class="col-sm-12">Gully</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="gully_id" name="gully_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $emptyGully; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($eg->id); ?>"><?php echo e($eg->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="benih_id" class="col-sm-12">Benih</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="benih_id" name="benih_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $benih; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($b->id); ?>"><?php echo e($b->barang); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="rockwool_id" class="col-sm-12">Rockwool</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="rockwool_id" name="rockwool_id" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <?php $__empty_1 = true; $__currentLoopData = $rockwool; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <option value="<?php echo e($r->id); ?>"><?php echo e($r->barang); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option disabled>Belum ada data</option>
                                    <?php endif; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12 d-flex">
                                <button class="btn btn-success mx-auto mx-md-0 text-white">Masukan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Kloter -->
        <!-- Barang -->
        <div class=" col-lg-4 col-xlg-9 col-md-7">
            <div class="card shadow">
                <div class="card-title text-center mt-3">
                    <h3>Tambah Barang Baru</h3>
                </div>
                <div class="card-body">
                    <form class="form-horizontal form-material mx-2" method="POST" action="<?php echo e(url('/inventory')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="jenis" class="col-sm-12">Jenis Barang</label>
                            <div class="col-sm-12 border-bottom">
                                <select id="jenis" name="jenis" class="form-select shadow-none border-0 ps-0 form-control-line">
                                    <option value="benih">Benih</option>
                                    <option value="rockwool">Rockwool</option>
                                    <option value="nutrisi">Nutrisi</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="barang" class="col-sm-12">Nama Barang</label>
                            <div class="col-sm-12 border-bottom">
                                <input type="text" class="form-control" name="barang" id="barang">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12 d-flex">
                                <button class="btn btn-success mx-auto mx-md-0 text-white">Masukan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- End Barang -->
    </div>
    <!-- Row -->
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalhaqq/Projects/Laravel/hidroman/resources/views/pages/input.blade.php ENDPATH**/ ?>