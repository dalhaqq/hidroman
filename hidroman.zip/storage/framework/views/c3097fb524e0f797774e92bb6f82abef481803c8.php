

<?php $__env->startSection('content'); ?>

<!-- ============================================================== -->
<!-- Container fluid  -->
<!-- ============================================================== -->
<div class="container-fluid">
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
    <div class="row">
        <!-- column -->
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h2 class="card-title">Kloter</h2>
                    <div class="table-responsive">
                        <table class="table user-table no-wrap text-center">
                            <thead>
                                <tr>
                                    <th class="border-top-0">Nomor Kloter</th>
                                    <th class="border-top-0">Gully</th>
                                    <th class="border-top-0">Jenis Tanaman</th>
                                    <th class="border-top-0">Tanggal Tanam</th>
                                    <th class="border-top-0">Tanggal Cabut</th>
                                    <th class="border-top-0">Total Nutrisi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $kloter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($k->id); ?></td>
                                    <td><?php echo e($k->gully->nama ?? ''); ?></td>
                                    <td><?php echo e($k->benih->barang); ?></td>
                                    <td><?php echo e($k->tgl_tanam); ?></td>
                                    <td><?php echo e($k->tgl_akhir); ?></td>
                                    <td><?php echo e($k->jml_nutrisi); ?> ml</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6">Tidak ada data</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End PAge Content -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Right sidebar -->
    <!-- ============================================================== -->
    <!-- .right-sidebar -->
    <!-- ============================================================== -->
    <!-- End Right sidebar -->
    <!-- ============================================================== -->
</div>
<!-- ============================================================== -->
<!-- End Container fluid  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dalhaqq/Projects/Laravel/hidroman/resources/views/pages/kloter.blade.php ENDPATH**/ ?>